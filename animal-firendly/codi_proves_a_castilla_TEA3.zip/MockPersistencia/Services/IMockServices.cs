﻿using MockPersistencia.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace MockPersistencia.Services
{
    public interface IMockServices
    {
    }
}
